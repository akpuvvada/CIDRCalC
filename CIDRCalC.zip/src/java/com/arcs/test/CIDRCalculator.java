package com.arcs.test;

import java.util.StringTokenizer;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Anil Puvvada
 */
public class CIDRCalculator extends javax.swing.JFrame {

    private void calculateIPRangeInfo() {
        int[] ip_address = new int[]{
            (int) jSpinner_IPAddress_Part1.getModel().getValue(),
            (int) jSpinner_IPAddress_Part2.getModel().getValue(),
            (int) jSpinner_IPAddress_Part3.getModel().getValue(),
            (int) jSpinner_IPAddress_Part4.getModel().getValue()
        };
        int prefix = (int) jSpinner_IPAddress_Prefix.getModel().getValue();

        String htmlContent = "<html><body><table>";
        {
            htmlContent = htmlContent + "<tr><td colspan=2><b>" + "IP Range Information" + "</b></td></tr>";
            htmlContent = htmlContent + "<tr><td><b>" + "IP Address" + "</b></td><td>" + ip_address[0] + "." + ip_address[1] + "." + ip_address[2] + "." + ip_address[3] + "</td></tr>";
            htmlContent = htmlContent + "<tr><td><b>" + "CIDR / Bitmask" + "</b></td><td>" + prefix + "</td></tr>";

            {
                int[] data = getNetworkAddress(ip_address, prefix);
                htmlContent = htmlContent + "<tr><td><b>" + "Network Address" + "</b></td><td>" + data[0] + "." + data[1] + "." + data[2] + "." + data[3] + "</td></tr>";
            }
            {
                int[] data1 = getFirstAddress(ip_address, prefix);
                int[] data2 = getLastAddress(ip_address, prefix);
                htmlContent = htmlContent + "<tr><td><b>" + "Usable Address" + "</b></td><td>" + data1[0] + "." + data1[1] + "." + data1[2] + "." + data1[3] + " -> " + data2[0] + "." + data2[1] + "." + data2[2] + "." + data2[3] + "</td></tr>";
                htmlContent = htmlContent + "<tr><td><b>" + "First Address" + "</b></td><td>" + data1[0] + "." + data1[1] + "." + data1[2] + "." + data1[3] + "</td></tr>";
                htmlContent = htmlContent + "<tr><td><b>" + "Last Address" + "</b></td><td>" + data2[0] + "." + data2[1] + "." + data2[2] + "." + data2[3] + "</td></tr>";
            }
            {
                int[] data = getBroadcastAddress(ip_address, prefix);
                htmlContent = htmlContent + "<tr><td><b>" + "Broadcast Address" + "</b></td><td>" + data[0] + "." + data[1] + "." + data[2] + "." + data[3] + "</td></tr>";
            }
            htmlContent = htmlContent + "<tr><td><b>" + "IP Class" + "</b></td><td>" + getNetworkClass(ip_address[0]) + "</td></tr>";
            htmlContent = htmlContent + "<tr><td colspan=2><b>" + "Subnet Information" + "</b></td></tr>";
            {
                int[] data = maskToArray(prefix);
                htmlContent = htmlContent + "<tr><td><b>" + "Subnet Mask" + "</b></td><td>" + data[0] + "." + data[1] + "." + data[2] + "." + data[3] + "</td></tr>";
            }
            {
                int[] data = getWildcard(prefix);
                htmlContent = htmlContent + "<tr><td><b>" + "Wildcard Address" + "</b></td><td>" + data[0] + "." + data[1] + "." + data[2] + "." + data[3] + "</td></tr>";
            }
            htmlContent = htmlContent + "<tr><td><b>" + "Available Number Of Host IP Addresses" + "</b></td><td>" + getAvailableHost(prefix) + "</td></tr>";
            htmlContent = htmlContent + "<tr><td><b>" + "Available Total Number Of IP Addresses" + "</b></td><td>" + (getAvailableHost(prefix) + 2) + "</td></tr>";
        }
        htmlContent = htmlContent + "</table></body></html>";
        jEditorPane_IPRangeInformation.setText(htmlContent);
    }

    private static int[] getWildcard(int prefix) {
        final int[] result = {0, 0, 0, 0};
        String mask = "";
        for (int i = 1; i <= 32; i++) {
            if (prefix <= 0) {
                mask += "1";
                if (i == 8 || i == 16 || i == 24) {
                    mask += ".";
                }
            } else {
                mask += "0";
                if (i == 8 || i == 16 || i == 24) {
                    mask += ".";
                }
            }
            prefix -= 1;
        }
        final StringTokenizer wildcard = new StringTokenizer(mask, ".");
        for (int i = 0; i < result.length; i++) {
            result[i] = Integer.parseInt(wildcard.nextToken(), 2);
        }
        return result;
    }

    private static int[] getBroadcastAddress(final int[] ip, final int prefix) {
        final int[] result = {0, 0, 0, 0};
        final int[] mask = getWildcard(prefix);
        for (int i = 0; i < result.length; i++) {
            result[i] = (ip[i] | mask[i]);
        }
        return result;
    }

    private static int[] getFirstAddress(final int[] ip, final int prefix) {
        final int[] result = getNetworkAddress(ip, prefix);
        result[3] += 1;
        return result;
    }

    private static int[] getLastAddress(final int[] ip, final int prefix) {
        final int[] result = getBroadcastAddress(ip, prefix);
        if(result[3] != 0) { result[3] -= 1; }
        return result;
    }

    private static int[] getNetworkAddress(final int[] ip, final int prefix) {
        final int[] result = {0, 0, 0, 0};
        final int[] subnet = maskToArray(prefix);
        for (int i = 0; i < result.length; i++) {
            result[i] = (ip[i] & subnet[i]);
        }
        return result;
    }

    private static int[] maskToArray(int prefix) {
        final int[] result = {0, 0, 0, 0};
        String mask = "";
        for (int i = 1; i <= 32; i++) {
            if (prefix > 0) {
                mask += "1";
                if (i == 8 || i == 16 || i == 24) {
                    mask += ".";
                }
            } else {
                mask += "0";
                if (i == 8 || i == 16 || i == 24) {
                    mask += ".";
                }
            }
            prefix -= 1;
        }
        final StringTokenizer subnet = new StringTokenizer(mask, ".");
        for (int i = 0; i < result.length; i++) {
            result[i] = Integer.parseInt(subnet.nextToken(), 2);
        }
        return result;
    }

    private static int[] getRecommendedSubnetwork(final int prefix) {
        final int host = (getAvailableHost(prefix) + 2) / 4;
        int buffer = 0;
        int i = 2;
        while (true) {
            buffer += 1;
            if (Math.pow(2, i) == host) {
                break;
            }
            i++;
        }
        i = 2;
        final int[] recommend = new int[buffer];
        for (int j = 0; j < buffer; j++) {
            recommend[j] = (int) Math.pow(2, i);
            i++;
        }
        return recommend;
    }

    private static int getAvailableHost(final int prefix) {
        final int result = (int) Math.pow(2, (32 - prefix)) - 2;
        return result;
    }

    /**
     * Creates new form CIDRCalculator
     */
    public CIDRCalculator() {
        initComponents();
        calculateIPRangeInfo();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel_IPAddress = new javax.swing.JLabel();
        jSpinner_IPAddress_Part2 = new javax.swing.JSpinner();
        jSpinner_IPAddress_Part1 = new javax.swing.JSpinner();
        jSpinner_IPAddress_Part3 = new javax.swing.JSpinner();
        jSpinner_IPAddress_Part4 = new javax.swing.JSpinner();
        jLabel_IPAddress_PrefixDevider = new javax.swing.JLabel();
        jSpinner_IPAddress_Prefix = new javax.swing.JSpinner();
        jCheckBox_ShowSubnets = new javax.swing.JCheckBox();
        jLabel_ShowSubnets_List = new javax.swing.JLabel();
        jComboBox_ShowSubnets_Selection = new javax.swing.JComboBox<>();
        jSplitPane_Output = new javax.swing.JSplitPane();
        jScrollPane_IPRangeInformation = new javax.swing.JScrollPane();
        jEditorPane_IPRangeInformation = new javax.swing.JEditorPane();
        jScrollPane_SubnetInfo = new javax.swing.JScrollPane();
        jEditorPane_SubnetInfo = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel_IPAddress.setText("IP Address :");

        jSpinner_IPAddress_Part2.setModel(new javax.swing.SpinnerNumberModel(168, 0, 255, 1));
        jSpinner_IPAddress_Part2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_IPAddress_Part2StateChanged(evt);
            }
        });

        jSpinner_IPAddress_Part1.setModel(new javax.swing.SpinnerNumberModel(192, 0, 255, 1));
        jSpinner_IPAddress_Part1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_IPAddress_Part1StateChanged(evt);
            }
        });

        jSpinner_IPAddress_Part3.setModel(new javax.swing.SpinnerNumberModel(1, 0, 255, 1));
        jSpinner_IPAddress_Part3.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_IPAddress_Part3StateChanged(evt);
            }
        });

        jSpinner_IPAddress_Part4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 255, 1));
        jSpinner_IPAddress_Part4.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_IPAddress_Part4StateChanged(evt);
            }
        });

        jLabel_IPAddress_PrefixDevider.setText("/");

        jSpinner_IPAddress_Prefix.setModel(new javax.swing.SpinnerNumberModel(32, 1, 32, 1));
        jSpinner_IPAddress_Prefix.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_IPAddress_PrefixStateChanged(evt);
            }
        });

        jCheckBox_ShowSubnets.setText("Show Subnets?");
        jCheckBox_ShowSubnets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox_ShowSubnetsActionPerformed(evt);
            }
        });

        jLabel_ShowSubnets_List.setText("Possible Subnets are Listed  - Select your option :");

        jComboBox_ShowSubnets_Selection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_ShowSubnets_SelectionActionPerformed(evt);
            }
        });

        jSplitPane_Output.setDividerLocation(200);
        jSplitPane_Output.setResizeWeight(0.5);

        jEditorPane_IPRangeInformation.setEditable(false);
        jEditorPane_IPRangeInformation.setContentType("text/html"); // NOI18N
        jScrollPane_IPRangeInformation.setViewportView(jEditorPane_IPRangeInformation);

        jSplitPane_Output.setLeftComponent(jScrollPane_IPRangeInformation);

        jEditorPane_SubnetInfo.setEditable(false);
        jEditorPane_SubnetInfo.setContentType("text/html"); // NOI18N
        jScrollPane_SubnetInfo.setViewportView(jEditorPane_SubnetInfo);

        jSplitPane_Output.setRightComponent(jScrollPane_SubnetInfo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSplitPane_Output)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel_IPAddress)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSpinner_IPAddress_Part1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSpinner_IPAddress_Part2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSpinner_IPAddress_Part3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSpinner_IPAddress_Part4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel_IPAddress_PrefixDevider)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSpinner_IPAddress_Prefix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jCheckBox_ShowSubnets)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel_ShowSubnets_List)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox_ShowSubnets_Selection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel_IPAddress)
                    .addComponent(jSpinner_IPAddress_Part1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner_IPAddress_Part2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner_IPAddress_Part3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner_IPAddress_Part4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_IPAddress_PrefixDevider)
                    .addComponent(jSpinner_IPAddress_Prefix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox_ShowSubnets)
                    .addComponent(jLabel_ShowSubnets_List)
                    .addComponent(jComboBox_ShowSubnets_Selection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSplitPane_Output, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBox_ShowSubnetsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox_ShowSubnetsActionPerformed
        // TODO add your handling code here:
        int[] data = getRecommendedSubnetwork(24);
        Integer[] dataI = new Integer[data.length];
        for (int i = 0; i < data.length; i++) {
            dataI[i] = data[i];
        }
        jComboBox_ShowSubnets_Selection.setModel(new DefaultComboBoxModel<Integer>(dataI));
    }//GEN-LAST:event_jCheckBox_ShowSubnetsActionPerformed

    private void jComboBox_ShowSubnets_SelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_ShowSubnets_SelectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_ShowSubnets_SelectionActionPerformed

    private void jSpinner_IPAddress_Part1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_IPAddress_Part1StateChanged
        // TODO add your handling code here:
        calculateIPRangeInfo();
    }//GEN-LAST:event_jSpinner_IPAddress_Part1StateChanged

    private void jSpinner_IPAddress_Part2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_IPAddress_Part2StateChanged
        // TODO add your handling code here:
        calculateIPRangeInfo();
    }//GEN-LAST:event_jSpinner_IPAddress_Part2StateChanged

    private void jSpinner_IPAddress_Part3StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_IPAddress_Part3StateChanged
        // TODO add your handling code here:
        calculateIPRangeInfo();
    }//GEN-LAST:event_jSpinner_IPAddress_Part3StateChanged

    private void jSpinner_IPAddress_Part4StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_IPAddress_Part4StateChanged
        // TODO add your handling code here:
        calculateIPRangeInfo();
    }//GEN-LAST:event_jSpinner_IPAddress_Part4StateChanged

    private void jSpinner_IPAddress_PrefixStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_IPAddress_PrefixStateChanged
        // TODO add your handling code here:
        calculateIPRangeInfo();
    }//GEN-LAST:event_jSpinner_IPAddress_PrefixStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CIDRCalculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CIDRCalculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CIDRCalculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CIDRCalculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CIDRCalculator().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox jCheckBox_ShowSubnets;
    private javax.swing.JComboBox<Integer> jComboBox_ShowSubnets_Selection;
    private javax.swing.JEditorPane jEditorPane_IPRangeInformation;
    private javax.swing.JEditorPane jEditorPane_SubnetInfo;
    private javax.swing.JLabel jLabel_IPAddress;
    private javax.swing.JLabel jLabel_IPAddress_PrefixDevider;
    private javax.swing.JLabel jLabel_ShowSubnets_List;
    private javax.swing.JScrollPane jScrollPane_IPRangeInformation;
    private javax.swing.JScrollPane jScrollPane_SubnetInfo;
    private javax.swing.JSpinner jSpinner_IPAddress_Part1;
    private javax.swing.JSpinner jSpinner_IPAddress_Part2;
    private javax.swing.JSpinner jSpinner_IPAddress_Part3;
    private javax.swing.JSpinner jSpinner_IPAddress_Part4;
    private javax.swing.JSpinner jSpinner_IPAddress_Prefix;
    private javax.swing.JSplitPane jSplitPane_Output;
    // End of variables declaration//GEN-END:variables

    private String getNetworkClass(int ip_addres_Part1) {
        if (ip_addres_Part1 >= 0 && ip_addres_Part1 <= 127) {
            return "A";
        }
        if (ip_addres_Part1 >= 128 && ip_addres_Part1 <= 191) {
            return "B";
        }
        if (ip_addres_Part1 >= 192 && ip_addres_Part1 <= 223) {
            return "C";
        }
        if (ip_addres_Part1 >= 224 && ip_addres_Part1 <= 239) {
            return "D";
        }
        if (ip_addres_Part1 >= 240 && ip_addres_Part1 <= 255) {
            return "E";
        }
        return "-error-";
    }
}
